```bash
mkdir server-side-sheet
cd server-side-sheet
git clone https://github.com/aaapwn/Server-Side-Web-Development.git aaapwn-and-gus
git clone https://github.com/FewPz/prepare-quiz01-swd67.git FewPz
git clone https://github.com/it-web-pro/django-week2.git aj-week2
git clone https://github.com/it-web-pro/django-week3.git aj-week3
git clone https://github.com/it-web-pro/django-week4.git aj-week4
git clone https://github.com/it-web-pro/django-week5.git aj-week5

```
