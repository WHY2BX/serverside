# Setup for Django (Week2)

### 1. Set up Virtual Environment

- Install virtualenv

    ```
    pip install virtualenv
    ```

- Create a virtual environment

    ```
    py -m venv myvenv
    ```

- Activate virtual environment

    ```
    myvenv\Scripts\activate.bat
    ```


### 2. Install Django, Postgres Database
```
pip install django
pip install psycopg2
pip install humanize
```


### 3. Creating Project
```python
django-admin startproject `pj_name`
```

- สำหรับเอาไว้ run server ทดสอบ

    ```python
    python manage.py runserver
    ```

- เปลี่ยน port ที่เอาไว้ run server

    ```python
    python manage.py runserver 8080
    ```

### 4. Create Apps
```
python manage.py startapp `app_name`
```
- สร้างแล้ว ให้ไปเพิ่มชื่อ app ใน setting.py ด้วย

    ```python
    INSTALLED_APPS = [
        "django.contrib.admin",
        "django.contrib.auth",
        "django.contrib.contenttypes",
        "django.contrib.sessions",
        "django.contrib.messages",
        "django.contrib.staticfiles",
        'django.contrib.humanize' <--

        # Add your apps here
        "app_name", <--
        
    ]
    ```


### 5. Database Setup
- Check version Postgres

    ```
    postgres --version
    ```

- Install เสร็จแล้ว ให้ไปแก้ไฟล์ setting.py ด้วย **(แก้ NAME, user, pass ด้วย)**
    ```python
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": "mypolls",
            "USER": "db_username",
            "PASSWORD": "password",
            "HOST": "localhost",
            "PORT": "5432",
        }
    }
    ```

### 6. Install Jupiter
```
pip install django-extensions ipython jupyter notebook
```

- แก้ version package ของ jupiter, notebook

    ```
    pip install ipython==8.25.0 jupyter_server==2.14.1 jupyterlab==4.2.2 jupyterlab_server==2.27.2
    ```
- แก้ version notebook

    ```
    pip install notebook==6.5.7
    ```

- ไปเพิ่ม Installed Apps ใน Setting ด้วย

    ```python
    INSTALLED_APPS = [
        "django.contrib.admin",
        "django.contrib.auth",
        "django.contrib.contenttypes",
        "django.contrib.sessions",
        "django.contrib.messages",
        "django.contrib.staticfiles",

        "django_extensions", <----
        "blogs",
    ]
    ```

> สร้าง folder notebook ไว้ใน folder project ระดับเดียวกับ app

- Start Jupiter Notebook Server

    ```
    python manage.py shell_plus --notebook
    ```
- run cell นี้ก่อนทุกครั้ง เวลาจะใช้ Jupiter notebook

    ```python
    import os
    os.environ["DJANGO_ALLOW_ASYNC_UNSAFE"] = "true"
    ```


> ถ้า run ไม่ได้ ลองเช็คใน notebook ว่าเปลี่ยน kernel เป็น django shell แล้วรึยัง

> ถ้ายัง run ไม่ได้อีก ติด synchronus บลาๆ ให้ลอง run cell แรกใหม่อีกรอบ

## ด้านบนของ file Models ต้อง Import เสมอ
```python
from django.db import models
```


## คำสั่ง Import?

```python
from django.db.models import *
from django.db.models.functions import *
from django.db.models.lookups import *
```

- ทำ print แบบ json
    ```python
    import json 
    (print(json.dumps(dictionary, indent=4, sort_keys=False)))
    from ชื่อapp.models import *
    ```

# Week 7 : The Views

> หมายเหตุ : ทั้งหมดเป็นแบบ class-based

> หมายเหตุ 2 : เวลาจะไฟล์ View เรียกใช้ object ของ models ไหน ให้ import เข้าด้วย

1. ใส่อันนี้ลงใน setting.py เพื่อบอกตำแหน่ง ไฟล์ template

    ```python
    import os
    SETTINGS_PATH = os.path.dirname(os.path.dirname(__file__))

    TEMPLATE_DIRS = (
        os.path.join(SETTINGS_PATH, 'templates'),
    )
    ```

- กำหนด url ใน urls.py --> เป็น url หลัก (folder project) เพื่อไปเข้าถึง apps อีกที

    ต้อง import อันนี้ไว้ด้านบนของ file ด้วย ถ้าจะใช้ include
    ```python
    from django.urls import path, include
    ```

    ```python
    urlpatterns = [
        path("admin/", admin.site.urls),
        path("polls/", include("polls.urls")),
    ]
    ```

- แล้วค่อยไปกำหนด urls เข้าถึงหน้าเว็ป (folder apps) ใน `/polls/urls.py` อีกที --> ต้องสร้าง file `urls.py` เอง

    ต้อง import ไว้ด้านบนของ file ด้วย

    ```python
    from django.urls import path
    from . import views
    ```

    ```python
    urlpatterns = [
        path("", views.IndexView.as_view(), name="index"),
        path("employee/", views.EmployeeView.as_view(), name="employee"),
        path("position/", views.PositionView.as_view(), name="postion"),
        path("project/", views.ProjectView.as_view(), name="project"),
        path("project/<int:project_id>/details/", views.DetailView.as_view(), name="details"),
        path("project/<int:project_id>/details/delete/", views.DeleteView.as_view(), name="deletePj"),
        path("project/<int:project_id>/details/add/<int:employee_id>/", views.DetailView.as_view(), name="add"),
        path("project/<int:project_id>/details/deleteStaff/<int:employee_id>/", views.DetailView.as_view(), name="deleteStaff"),
    ]
    ```

- Class-based View template

    ```python
    from django.shortcuts import render, redirect
    from django.views import View

    from .models import Question, Choice


    class IndexView(View):

        def get(self, request):
            latest_question_list = Question.objects.order_by("-pub_date")[:5]
            context = {
                "latest_question_list": latest_question_list,
                }
            return render(request, "index.html", context)
    ```

- Date time format

    ```python
    start = project.start_date.strftime('%Y-%m-%d')
    ```

- ใช้สำหรับเวลา ลบ-เพิ่ม ละให้ refresh หน้าเอง auto
    ```python
    return JsonResponse({'foo':'bar'}, status=200)
    ```

# Week 8 :

1. เพิ่มการกำหนดว่า static files ของโปรเจคจะอยู่ที่ folder ไหนใน settings.py

    ```python
    STATIC_URL = "static/"

    STATICFILES_DIRS = [
        BASE_DIR / "static",
    ]
    ```

2. Url pattern

    ```python
    {% url 'name' pj.id %}
    ```

3. Layout.py Patterns
    ```html
    {% load static %}
    <!DOCTYPE html>
    <html>
        <head>
            <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{% block page_title %} {% endblock %}</title>
        <link rel="stylesheet" href="{% static 'css/bulma.css' %}">
        </head>
        <body>
            <section class="section">
                <h1 class="title">{% block header %}  {% endblock %} </h1>
                <div class="content">
                {% block content %}
                {% endblock %}
                </div>
            </section>
            <section class="section">
                <p class="subtitle">
                    {% block footer %} {%endblock%}
                </p>
            </section>
        </body>
    </html>
    {% block scripts %} {% endblock %}
    ```

4. Extends Page Patterns

    ```python
    {% extends 'base.html' %}

    {% block title %} {%endblock%}

    {% block header %} {%endblock%}

    {% block content %}
    {%endblock%}

    {% block footer %}
    {%endblock%}

    {% block scripts %} {% endblock %}
    ```

5. เวลาจะใช้ Layout --> ให้ Extends ไปด้วย **เติม S ด้วยย**
    ```
    {% extends "base.html" %}
    ```

6. ใน Layout -> ใช้ include nav.html เอา
    ```
    {% include nav.html %}
    ```

7. ต้อง import file css, js เข้ามาด้วย

    ```html
    <link rel="stylesheet" href="{% static 'css/bulma.css' %}">

    <script type="text/javascript" src="{% static 'manage_staff.js' %}"></script>
    <script type="text/javascript" src="{% static 'project.js' %}"></script>
    ```

8. เวลาส่ง parameter crsf เป็น string ใช้

    ```
    '{{csrf_token}}'
    ```

9. ดึงค่าจาก input ด้วย js
    ```js
    const emp = document.getElementById('input-add-staff');
    const emp_id = emp.value;
    ```

> เวลา load file ข้างนอก ให้ใส่ข้างล่าง extends
