from django import forms
from .models import *
from django.forms import ModelForm, SplitDateTimeField
from django.forms.widgets import Textarea, TextInput, SplitDateTimeWidget
from django.core.exceptions import ValidationError
from datetime import datetime

from django.forms import ModelForm

class NewEmployeeForm(ModelForm):
    class Meta:
        model = Employee

        fields = ["first_name", "last_name", "birth_date", 'hire_date', 'salary', 'position', 'gender']
        widgets = {
            "birth_date": forms.DateInput(attrs={'type':'date'}),
            "hire_date": forms.DateInput(attrs={'type':'date'}),
            # "salary": forms.DecimalField(),
        }

    #validated
    def clean_hire_date(self):
        hire_date = self.cleaned_data.get("hire_date")
        now = datetime.now().date()

        if hire_date and now and now < hire_date:
            self.add_error(
                'hire_date',
                "hire date can't be in the future"
            )

        return hire_date
    
class NewProjectForm(ModelForm):
    class Meta:
        model = Project

        fields = ["name", "manager", 'due_date', 'start_date', "description"]
        widgets = {
            "due_date": forms.DateInput(attrs={'type':'date'}),
            "start_date": forms.DateInput(attrs={'type':'date'}),
        }

    def clean_start_date(self):
        due_date = self.cleaned_data.get("due_date")
        start_date = self.cleaned_data.get("start_date") 

        if start_date and due_date and due_date < start_date:
            self.add_error(
                'start_date',
                "can't start after due bro"
            )

        return start_date

class EditProjectDetailsForm(ModelForm):
    class Meta:
        model = Project

        fields = ["name", "manager", 'due_date', 'start_date', "description", 'staff']
        widgets = {
            "due_date": forms.DateInput(attrs={'type':'date'}),
            "start_date": forms.DateInput(attrs={'type':'date'}),
        }

    def clean_start_date(self):
        due_date = self.cleaned_data.get("due_date")
        start_date = self.cleaned_data.get("start_date") 

        if start_date and due_date and due_date < start_date:
            self.add_error(
                'start_date',
                "can't start after due bro"
            )

        return start_date

    # def clean_start_date(self):
    #     due_date = self.cleaned_data.get("due_date")
    #     start_date = self.cleaned_data.get("start_date") 

    #     if start_date and due_date and due_date < start_date:
    #         self.add_error(
    #             'start_date',
    #             "can't start after due bro"
    #         )

    #     return start_date

# -------------------------------------------------------------------------------------------

# class NewEmployeeForm(forms.Form):
#     first_name = forms.CharField(label="First name", max_length=100, )
#     last_name = forms.CharField(label="Last name", max_length=100)

#     gender_choices = (
#         ('M', 'Male'),
#         ('F', 'Female'),
#         ('LGBT', 'LGBT')
#     )

#     gender = forms.ChoiceField(
#             choices=gender_choices
#         )

#     birth_date = forms.DateField(label='Birth date', widget=forms.DateInput(attrs={'type':'date'}))
#     hire_date = forms.DateField(label='Hire date', widget=forms.DateInput(attrs={'type':'date'}))
#     salary = forms.DecimalField(label='Salary')

#     position = forms.ModelChoiceField(
#         queryset=Position.objects.all()
#     )