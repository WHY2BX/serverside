from django.shortcuts import render, redirect
from django.views import View
from .models import Employee, Project
from django.db.models import *
from company.models import Position
from django.http import JsonResponse, HttpResponse
from .forms import *
from django.db import transaction

class IndexView(View):
    def get(self, request):
        return render(request, "index.html")
    

class EmployeeView(View):
    def get(self, request):
        employee_list = Employee.objects.all().order_by('-hire_date')
        context = {"employee_list": employee_list}
        return render(request, "employee.html", context)

class PositionView(View):
    def get(self, request):
        employee_list = Position.objects.using('db2').all().values('name', 'id').annotate(Count=Count('employee_id')).order_by('id')
        # position_list = Position.objects.all()
        context = {"employee_list": employee_list,
                #    'postion_list':position_list,
                   }
        return render(request, "position.html", context)
    
class ProjectView(View):
    def get(self, request):
        project_list = Project.objects.all()
        context = {"project_list": project_list,}
        return render(request, "project.html", context)
    

class DetailView(View):
    def get(self, request, project_id):
        project = Project.objects.get(pk=project_id)
        start = project.start_date.strftime('%Y-%m-%d')
        due = project.due_date.strftime('%Y-%m-%d')
        return render(request, "project_detail.html", {
            "project": project,
            'start':start,
            'due':due,
        })
    
    def put(self, request, project_id, employee_id):
        proj = Project.objects.get(pk=project_id)
        emp = Employee.objects.get(pk=employee_id)
        proj.staff.add(emp)
        return JsonResponse({'addStaff':'add'}, status=200)
    
    def delete(self, request, project_id, employee_id):
        proj = Project.objects.get(pk=project_id)
        emp = Employee.objects.get(pk=employee_id)
        proj.staff.remove(emp)
        return JsonResponse({'removeStaff':'remove'}, status=200)
    
class DeleteView(View):
    def delete(self, request, project_id):
        project = Project.objects.get(pk=project_id)
        project.delete()

        return JsonResponse({'foo':'bar'}, status=200)

@transaction.atomic
def NewEmployeeView(request):
    
    if request.method == "POST":
        form = NewEmployeeForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data)
            emp = Employee.objects.create(
                first_name = form.cleaned_data['first_name'], 
                last_name = form.cleaned_data['last_name'],
                gender = form.cleaned_data['gender'],   
                birth_date = form.cleaned_data['birth_date'],
                hire_date = form.cleaned_data['hire_date'],
                salary = form.cleaned_data['salary'],
                position = form.cleaned_data['position']
                )
            EmployeeAddress.objects.create(
                employee = emp,
                location = form.cleaned_data['location'],
                district = form.cleaned_data['district'],
                province = form.cleaned_data['province'],
                postal_code = form.cleaned_data['postal_code']
            )
            return redirect('employee')
    else:
        form = NewEmployeeForm()

    return render(request, "employee_form.html", {"NewEmpform": form})

def NewProjectView(request):

    if request.method == "POST":
        form = NewProjectForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data)
            Project.objects.create(
                name = form.cleaned_data['name'], 
                description = form.cleaned_data['description'],
                manager = form.cleaned_data['manager'],   
                due_date = form.cleaned_data['due_date'],
                start_date = form.cleaned_data['start_date'],
                )
            
            return redirect('project')
    else:
        form = NewProjectForm()

    return render(request, "project_form.html", {"form": form})


def EditProjectDetail(request, project_id):
    project = Project.objects.get(pk=project_id)

    if request.method == "POST":
        form = EditProjectDetailsForm(request.POST, instance=project)
        if form.is_valid():
            print(form.cleaned_data)
            form.save()                                                                          
            return redirect('details', project_id=project_id)
        else:
            return render(request, "project_detail.html", {"form": form}) 
    else:
        form = EditProjectDetailsForm(instance=project)

    return render(request, "project_detail.html", {"form": form, 'project':project})
