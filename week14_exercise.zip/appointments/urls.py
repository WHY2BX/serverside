from .views import *
from django.urls import path

urlpatterns = [
    path('doctors/', DoctorList.as_view(), name='doctor-list'),
    path('patients/', PatientList.as_view(), name='patient-list'),
    path('appointments/', AppointmentsList.as_view(), name='appointment-list'),
    path('appointments/<int:appnt_id>/', AppointmentsDetails.as_view(), name='appointment-details'),
]