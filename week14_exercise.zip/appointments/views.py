from django.shortcuts import render

from .models import *
from .serializers import *
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

# -----
from django.contrib.auth.models import User

from appointments.models import *
from appointments.serializers import *
from django.http import Http404
from rest_framework.views import APIView

from rest_framework.permissions import IsAuthenticatedOrReadOnly, IsAuthenticated
from rest_framework.authentication import TokenAuthentication

from appointments.permissions import *


class MyTokenAuthentication(TokenAuthentication):
    keyword = "Bearer"

class DoctorList(APIView):

    authentication_classes = [MyTokenAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        doctors = Doctor.objects.all()
        serializer = DoctorSerializer(doctors, many=True)
        return Response(serializer.data)

class PatientList(APIView):

    authentication_classes = [MyTokenAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        patients = Patient.objects.all()
        serializer = PatientSerializer(patients, many=True)
        return Response(serializer.data)

class AppointmentsList(APIView):

    authentication_classes = [MyTokenAuthentication]
    permission_classes = [IsAuthenticatedOrReadOnly, AnnonyAppointmentPermission]

    def get(self, request):
        appoint = Appointment.objects.all()
        serializer = AppointmentSerializer(appoint, many=True)

        return Response(serializer.data)
    
    def post(self, request):
        serializer = CreateAppointmentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    
class AppointmentsDetails(APIView):

    authentication_classes = [MyTokenAuthentication]
    permission_classes = [IsAuthenticated, AppointmentPermission]

    def get_object(self, pk):
        try:
            return Appointment.objects.get(pk=pk)
        except Appointment.DoesNotExist:
            raise Http404

    def get(self, request, appnt_id):
        appoint = self.get_object(appnt_id)
        serializer = AppointmentSerializer(appoint)

        if serializer:
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=404)
    
    def put(self, request, appnt_id, format=None):

        appoint = self.get_object(appnt_id)
        self.check_object_permissions(request, appoint)
        serializer = CreateAppointmentSerializer(appoint, data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    def patch(self, request, appnt_id, format=None):

        appoint = self.get_object(appnt_id)
        self.check_object_permissions(request, appoint)
        serializer = CreateAppointmentSerializer(appoint, data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    def delete(self, request, appnt_id, format=None):
        appoint = self.get_object(appnt_id)
        self.check_object_permissions(request, appoint)
        appoint.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    