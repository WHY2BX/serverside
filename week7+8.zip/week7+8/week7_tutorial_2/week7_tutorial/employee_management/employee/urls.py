from django.urls import path

from . import views

urlpatterns = [
    path("", views.IndexView.as_view(), name="index"),
    path("employee/", views.EmployeeView.as_view(), name="employee"),
    path("position/", views.PositionView.as_view(), name="postion"),
    path("project/", views.ProjectView.as_view(), name="project"),
    path("project/<int:project_id>/details/", views.DetailView.as_view(), name="details"),
    path("project/<int:project_id>/details/delete/", views.DeleteView.as_view(), name="deletePj"),
    path("project/<int:project_id>/details/add/<int:employee_id>/", views.DetailView.as_view(), name="add"),
    path("project/<int:project_id>/details/deleteStaff/<int:employee_id>/", views.DetailView.as_view(), name="deleteStaff"),
]