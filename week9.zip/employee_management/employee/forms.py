from django import forms
from .models import *

class NewEmployeeForm(forms.Form):
    first_name = forms.CharField(label="First name", max_length=100, )
    last_name = forms.CharField(label="Last name", max_length=100)

    gender_choices = (
        ('M', 'Male'),
        ('F', 'Female'),
        ('LGBT', 'LGBT')
    )

    gender = forms.ChoiceField(
            choices=gender_choices
        )

    birth_date = forms.DateField(label='Birth date', widget=forms.DateInput(attrs={'type':'date'}))
    hire_date = forms.DateField(label='Hire date', widget=forms.DateInput(attrs={'type':'date'}))
    salary = forms.DecimalField(label='Salary')

    position = forms.ModelChoiceField(
        queryset=Position.objects.all()
    )