from django.shortcuts import render, redirect
from django.views import View
from .models import Employee, Project
from django.db.models import *
from django.http import JsonResponse, HttpResponse
from .forms import *


class IndexView(View):
    def get(self, request):
        return render(request, "index.html")
    

class EmployeeView(View):
    def get(self, request):
        employee_list = Employee.objects.all().order_by('-hire_date')
        context = {"employee_list": employee_list}
        return render(request, "employee.html", context)

class PositionView(View):
    def get(self, request):
        employee_list = Employee.objects.values('position_id', 'position__name').annotate(count=Count('id')).order_by('position__id')
        # position_list = Position.objects.all()
        context = {"employee_list": employee_list,
                #    'postion_list':position_list,
                   }
        return render(request, "position.html", context)
    
class ProjectView(View):
    def get(self, request):
        project_list = Project.objects.all()
        context = {"project_list": project_list,}
        return render(request, "project.html", context)
    

class DetailView(View):
    def get(self, request, project_id):
        project = Project.objects.get(pk=project_id)
        start = project.start_date.strftime('%Y-%m-%d')
        due = project.due_date.strftime('%Y-%m-%d')
        return render(request, "project_detail.html", {
            "project": project,
            'start':start,
            'due':due,
        })
    
    def put(self, request, project_id, employee_id):
        proj = Project.objects.get(pk=project_id)
        emp = Employee.objects.get(pk=employee_id)
        proj.staff.add(emp)
        return JsonResponse({'addStaff':'add'}, status=200)
    
    def delete(self, request, project_id, employee_id):
        proj = Project.objects.get(pk=project_id)
        emp = Employee.objects.get(pk=employee_id)
        proj.staff.remove(emp)
        return JsonResponse({'removeStaff':'remove'}, status=200)
    
class DeleteView(View):
    def delete(self, request, project_id):
        project = Project.objects.get(pk=project_id)
        project.delete()

        return JsonResponse({'foo':'bar'}, status=200)

def NewEmployeeView(request):
    if request.method == "POST":
        form = NewEmployeeForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data)
            Employee.objects.create(
                first_name = form.cleaned_data['first_name'], 
                last_name = form.cleaned_data['last_name'],
                gender = form.cleaned_data['gender'],   
                birth_date = form.cleaned_data['birth_date'],
                hire_date = form.cleaned_data['hire_date'],
                salary = form.cleaned_data['salary'],
                position = form.cleaned_data['position']
                )
            return redirect('employee')
    else:
        form = NewEmployeeForm()

    return render(request, "employee_form.html", {"form": form})